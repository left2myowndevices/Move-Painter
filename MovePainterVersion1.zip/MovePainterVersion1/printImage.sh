#!/bin/bash
echo sup WAT WAT
inotifywait -m ./images -e create -e moved_to |
    while read path action file; do
        echo "The file '$file' appeared in directory '$path' via '$action'"
	echo $file
	sleep 5
        lpr ./images/$file
    done
